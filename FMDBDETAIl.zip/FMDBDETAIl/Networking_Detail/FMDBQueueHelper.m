//
//  FMDBQueueHelper.m
//  Networking_Detail
//
//  Created by hongliang li on 2018/1/19.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import "FMDBQueueHelper.h"

@implementation FMDBQueueHelper
+ (instancetype)shareFmdb{
    static  FMDBQueueHelper *hepler;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        hepler = [[FMDBQueueHelper alloc]init];
        NSString *patch =  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
        NSString *fileName = [patch stringByAppendingPathComponent:@"teacher.sqlite"];
        NSLog(@"ssssssssssssssss%@",fileName);
        hepler.QueueDb = [FMDatabaseQueue databaseQueueWithPath:fileName];
    });
    return hepler;
}

- (void)creatFMdb{
    [self.QueueDb inDatabase:^(FMDatabase * _Nonnull db) {
            BOOL ishave =  [db executeUpdate:@"CREATE TABLE IF NOT EXISTS OneCLass(id integer primary key AUTOINCREMENT,name text,age text)"];
            if (ishave) {
                NSLog(@"======成功");
            }else{
                NSLog(@"=========失败");
            }
    }];
}

- (void)add{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self.QueueDb inDatabase:^(FMDatabase * _Nonnull db) {
            for (NSInteger i = 0; i < 50000; i++) {
                NSString *s_name=[NSString stringWithFormat:@"Andy%d",arc4random()%100];
                NSString *s_age=[NSString stringWithFormat:@"Age_%ld",i];
                BOOL add = [db executeUpdate:@"insert into OneCLass(name,age)Values(?,?)",s_name,s_age];
                if (add) {
                    NSLog(@"=========插入成功======%ld",i);
                }else{
                    NSLog(@"=========插入失败");
                }
            }
        }];
    });
}

- (void)selectOne{
    NSLog(@"MMMMMMMMMMMM");
     dispatch_async(dispatch_get_global_queue(0, 0), ^{
       [self.QueueDb inDatabase:^(FMDatabase * _Nonnull db) {
        FMResultSet *set = [db executeQuery:@"select * from OneCLass where id <  300"];
           NSLog(@"===========qqq");
        while ([set next]) {
            //        set.columnNameToIndexMap 获取查询的对象字典
            NSLog(@"sssssssss============%@",set.resultDictionary);
        }
      }];
    });
}

@end
