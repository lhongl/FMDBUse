//
//  QueueViewController.m
//  Networking_Detail
//
//  Created by hongliang li on 2018/1/19.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import "QueueViewController.h"
#import "FMDBQueueHelper.h"
@interface QueueViewController ()

@end

@implementation QueueViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)creat:(id)sender {
    [[FMDBQueueHelper  shareFmdb] creatFMdb];
}
- (IBAction)add:(id)sender {
     [[FMDBQueueHelper  shareFmdb] add];
}
- (IBAction)delete:(id)sender {
}
- (IBAction)update:(id)sender {
}
- (IBAction)selectOne:(id)sender {
     [[FMDBQueueHelper  shareFmdb] selectOne];
}
- (IBAction)selectAll:(id)sender {
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
