//
//  FMDBQueueHelper.h
//  Networking_Detail
//
//  Created by hongliang li on 2018/1/19.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"
@interface FMDBQueueHelper : NSObject
@property (nonatomic, strong)FMDatabaseQueue *QueueDb;

+ (instancetype)shareFmdb;

- (void)creatFMdb;

- (void)add;

- (void)selectOne;
@end
