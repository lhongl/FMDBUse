//
//  ViewController.m
//  Networking_Detail
//
//  Created by hongliang li on 2018/1/18.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "FMDB.h"
#import "QueueViewController.h"
@interface ViewController ()
@property (nonatomic, strong)FMDatabase  *db;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   NSString *patch =  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString *fileName = [patch stringByAppendingPathComponent:@"student.sqlite"];
    NSLog(@"============%@",fileName);
    _db = [FMDatabase databaseWithPath:fileName];
    if ([_db open]) {
        NSLog(@"=========打开成功");
    }else{
        NSLog(@"=========打开失败");
    }
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)cj:(id)sender {
    BOOL cj = [_db executeUpdate:@"CREATE TABLE IF NOT EXISTS OneCLass(id integer primary key AUTOINCREMENT,name text,age text)"];
    if (cj) {
        NSLog(@"+++++++=创建成功");
    }else{
         NSLog(@"+++++++=创建失败");
    }
}

- (IBAction)add:(id)sender {
    for (NSInteger i = 0; i < 100; i++) {
        NSString *name = [NSString stringWithFormat:@"liyan_%ld",i];
        NSString *age = [NSString stringWithFormat:@"age_%ld",i];
      BOOL add =  [_db executeUpdate:@"insert into OneCLass(name,age) Values(?,?)",name,age];
        if (add) {
            NSLog(@"==========添加成功");
        }else{
            NSLog(@"==========添加失败");
        }
    }
    
}
- (IBAction)dele:(id)sender {
   BOOL delete = [_db executeUpdate:@"delete from OneCLass where id = 100"];
    if (delete) {
        NSLog(@"========删除成功");
    }else{
         NSLog(@"========删除失败");
    }
    
}
- (IBAction)update:(id)sender {
    BOOL update = [_db executeUpdate:@"update OneCLass set name = ? where name = ?",@"220220",@"liyan_50"];
    if (update) {
        NSLog(@"修改成功");
    }else{
        NSLog(@"========修改失败");
    }
}
- (IBAction)chaxunone:(id)sender {
    FMResultSet *set = [_db executeQuery:@"select * from OneCLass where name = ?",@"liyan_20"];
    while ([set next]) {
//        set.columnNameToIndexMap 获取查询的对象字典
        NSLog(@"sssssssss============%@",set.resultDictionary);
    }
    
}
- (IBAction)chaxunAll:(id)sender {
    FMResultSet *set = [_db executeQuery:@"select * from OneCLass"];
    while ([set next]) {
        //        set.columnNameToIndexMap 获取查询的对象字典
        NSLog(@"sssssssss============%@",set.resultDictionary);
    }
    
}
- (IBAction)QueueItem:(id)sender {
    QueueViewController *vc = [[QueueViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
