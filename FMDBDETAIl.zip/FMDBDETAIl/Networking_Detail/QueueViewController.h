//
//  QueueViewController.h
//  Networking_Detail
//
//  Created by hongliang li on 2018/1/19.
//  Copyright © 2018年 hongliang li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QueueViewController : UIViewController

@end
